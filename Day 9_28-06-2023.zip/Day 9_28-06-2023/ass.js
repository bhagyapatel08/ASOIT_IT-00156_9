let z = 2;
let y = 5;
console.log(x += y);